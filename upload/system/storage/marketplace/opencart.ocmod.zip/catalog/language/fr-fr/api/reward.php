<?php
// Texte
$_['text_success']   = 'Succès: Le rabais sur vos points de récompenses a été appliqué!';

// Erreur
$_['error_customer'] = 'Attention: Les détails du client sont requis!';
$_['error_product']  = 'Attention: Le produit est requis!';
$_['error_points']   = 'Attention: Vous n\'avez pas %s de points de récompenses!';
$_['error_maximum']  = 'Attention: Le nombre maximum de points qui peut être appliqué est de %s!';
$_['error_status']   = 'Attention: Les points de récompenses ne sont pas activés dans cette boutique!';
$_['error_confirm']  = 'Attention: Veuillez vérifier le formulaire attentivement pour les erreurs!';
