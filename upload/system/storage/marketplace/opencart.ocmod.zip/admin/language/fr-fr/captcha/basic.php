<?php
// En-tête
$_['heading_title']    = 'Captcha par Défaut';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié Captcha par Défaut!';
$_['text_edit']        = 'Modifier Captcha par Défaut';

// Entrée
$_['entry_status']     = 'Statut';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier Captcha par Défaut!';
