<?php
// Text
$_['text_cookie'] = 'Success: You have modified CookieCuttr!';