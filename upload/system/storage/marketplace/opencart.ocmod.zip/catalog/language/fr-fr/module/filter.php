<?php
// En-tête
$_['heading_title'] = 'Affiner la Recherche';
