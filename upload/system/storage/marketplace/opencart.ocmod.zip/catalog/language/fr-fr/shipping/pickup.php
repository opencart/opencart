<?php
// En-tête
$_['heading_title']    = 'Récupération en Magasin';

// Texte
$_['text_description'] = 'Récupération à partir de la boutique';
