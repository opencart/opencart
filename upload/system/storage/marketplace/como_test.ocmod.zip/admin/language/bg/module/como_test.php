<?php
// Heading
$_['heading_title']         = ' Como Test extension';

// Text
$_['text_extension']              = 'Разширения';
$_['text_success']                = 'Успех: Променихте параметрите на модул Como Test extension!';
$_['text_edit']                   = 'Редакция на модул Como Test extension';

// Entry
$_['entry_status']                = 'Статус';

// Error
$_['error_permission']        = 'Внимание: Нямате права за Como Test extension!';
