<?php
// Texte
$_['text_low_order_fee'] = 'Frais de Traitement Faible Commande';
