<?php
// En-tête
$_['heading_title'] = 'Nos Meilleurs Ventes';
