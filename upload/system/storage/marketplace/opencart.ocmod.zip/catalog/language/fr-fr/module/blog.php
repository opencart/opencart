<?php
// En-tête
$_['heading_title'] = 'Blogues';
