<?php
// En-tête
$_['heading_title'] = 'En Vedette';
