<?php
// Texte
$_['text_total'] = 'Totaux';
