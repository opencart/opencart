<?php
// Texte
$_['text_coupon']  = 'Coupon';

// Entrée
$_['entry_coupon'] = 'Coupon';
