<?php
// Texte
$_['text_sub_total'] = 'Sous-Total';
