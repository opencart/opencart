<?php
namespace Opencart\Admin\Controller\Extension\ComoTest\Module;
class ComoTest extends \Opencart\System\Engine\Controller {

    private $error = array();
    private $setting_defaults = array();

    protected function setting_defaults_init(): void {
        $this->setting_defaults = array(
            'module_como_test_status' => 1,
        );
    }

    public function install(): void {
        file_put_contents('info_data$install.txt', print_r('--', true));
        $this->setting_defaults_init();
        $this->load->model('setting/setting');
        $this->model_setting_setting->editSetting('module_como_test', $this->setting_defaults);

        $this->setUsergroupPermissions('extension/como_test/module/como_test');
    }

    public function uninstall(): void {
        file_put_contents('info_data$uninstall.txt', print_r('--', true));
        $this->load->model('setting/event');
        $this->model_setting_event->deleteEventByCode('como_test');
    }

    // set access permissions to all user groups
	protected function setUsergroupPermissions($route, $typeperm = 'access'): void {
        $this->load->model('user/user_group');
        $user_groups = $this->model_user_user_group->getUserGroups();
        if ($user_groups && is_array($user_groups)) {
            foreach($user_groups as $user_group) {
                $user_group['permission'] = json_decode($user_group['permission'], true);
                if (!isset($user_group['permission'][$typeperm]) || !in_array($route, $user_group['permission'][$typeperm])) {
                    $this->model_user_user_group->addPermission($user_group['user_group_id'], $typeperm, $route);
                }
            }
        }
    }

    public function index(): void {
        $this->load->language('extension/como_test/module/como_test');

        $this->document->setTitle($this->language->get('heading_title'));


        // Add module events
        $this->load->model('setting/event');
        $event_code = 'como_test';
        $events = array(
            //'admin/view/common/footer/after' => 'extension/como_test/module/como_test|eventAdminViewCommonFooterAfter', // footer
        );
        $description = 'Como Test module';
        $status = true;
        foreach($events as $trigger => $action) {
            $count_events = $this->db->query("SELECT COUNT(event_id) AS `total` FROM `" . DB_PREFIX . "event` WHERE `code` = '" . $this->db->escape($event_code) . "' AND `trigger` = '" . $this->db->escape($trigger) . "' AND `action` = '" . $this->db->escape($action) . "'")->row['total'];
            if (!$count_events) {
                $this->model_setting_event->addEvent($event_code, $description, $trigger, $action, $status);
            }
        }

        // get module config data
        $this->setting_defaults_init();
        foreach ($this->setting_defaults as $confKey => $defaultValue) {
            if ($this->config->has($confKey)) {
                $data[$confKey] = $this->config->get($confKey);
            } else {
                $data[$confKey] = $defaultValue;
            }
        }

        $this->dataWarningSuccessHandle($data);

        $data['breadcrumbs'] = $this->buildBreadcrumbs();

        $data['save'] = $this->url->link('extension/como_test/module/como_test|save', 'user_token=' . $this->session->data['user_token']);
        $data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module');

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/como_test/module/como_test', $data));
    }

	public function save(): void {
		$this->load->language('extension/como_test/module/como_test');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/como_test/module/como_test')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$json) {
            $this->load->model('setting/setting');
            $this->model_setting_setting->editSetting('module_como_test', $this->request->post);

			$json['success'] = $this->language->get('text_success');
            if (isset($this->request->post['saveandreturn']) && $this->request->post['saveandreturn']) {
                $json['redirect'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
            }
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/como_test/module/como_test')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }

    protected function buildBreadcrumbs($function = '', $title = '') {
        $data = array();
		$data[] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data[] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);
        $data[] = array(
            'text'      => $this->language->get('heading_title'),
            'href'      => $this->url->link('extension/como_test/module/como_test', 'user_token=' . $this->session->data['user_token'], true)
        );
        if ($function) {
            $data[] = array(
                'text'      => $title,
                'href'      => $this->url->link('extension/como_test/module/como_test/' . $function, 'user_token=' . $this->session->data['user_token'], true)
            );
        }

        return $data;
    }

    protected function dataWarningSuccessHandle(&$data) {
        if (isset($this->error['warning']) && $this->error['warning']) {
            $data['error_warning'] = $this->error['warning'];
		} elseif (isset($this->session->data['error']) && $this->session->data['error']) {
            $data['error_warning'] = $this->session->data['error'];
			unset($this->session->data['error']);
        } elseif (isset($this->session->data['warning']) && $this->session->data['warning']) {
			$data['error_warning'] = $this->session->data['warning'];
			unset($this->session->data['warning']);
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
    }
}