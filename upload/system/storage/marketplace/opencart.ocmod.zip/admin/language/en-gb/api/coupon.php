<?php
// Text
$_['text_coupon']  = 'Coupon';

// Entry
$_['entry_coupon'] = 'Coupon';
