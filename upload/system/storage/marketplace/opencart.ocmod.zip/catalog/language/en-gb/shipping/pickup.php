<?php
// Heading
$_['heading_title']    = 'Pickup';

// Text
$_['text_description'] = 'Pickup From Store';