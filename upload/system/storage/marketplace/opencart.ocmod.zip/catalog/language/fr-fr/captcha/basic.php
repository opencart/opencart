<?php
// Texte
$_['text_captcha']  = 'Captcha';

// Entrée
$_['entry_captcha'] = 'Veuillez entrer le code that la boîte ci-dessous';

// Erreur
$_['error_captcha'] = 'Le code de vérification ne correspond pas avec l\'image!';
