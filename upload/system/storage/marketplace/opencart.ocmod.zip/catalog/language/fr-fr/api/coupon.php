<?php
// Texte
$_['text_success']   = 'Succès: Votre coupon a été appliqué!';

// Erreur
$_['error_customer'] = 'Attention: Les détails du client sont requis!';
$_['error_product']  = 'Attention: Le produit est requis!';
$_['error_coupon']   = 'Attention: Le coupon est soit invalide, expiré, ou a atteint sa limite d\'utilisation!';
$_['error_status']   = 'Attention: Les coupons ne sont pas activés dans cette boutique!';
$_['error_confirm']  = 'Attention: Veuillez vérifier le formulaire attentivement pour les erreurs!';
