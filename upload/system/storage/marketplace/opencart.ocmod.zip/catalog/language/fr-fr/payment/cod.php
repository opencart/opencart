<?php
// En-tête
$_['heading_title']        = 'Contres Remboursements';

// Erreur
$_['error_order_id']       = 'Aucune ID de commande dans la session!';
$_['error_payment_method'] = 'La méthode de paiement est incorrecte!';
