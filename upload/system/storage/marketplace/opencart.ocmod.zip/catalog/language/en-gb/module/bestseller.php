<?php
// Heading
$_['heading_title'] = 'Best Sellers';