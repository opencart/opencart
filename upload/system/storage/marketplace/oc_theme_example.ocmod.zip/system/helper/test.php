<?php
namespace Opencart\System\Helper\Extension\OcThemeExample;
function my_function(): void {
	echo 'works';
}