<?php
namespace Opencart\System\Helper\Extension\OcThemeExample;
function my_function() {
	echo 'works';
}