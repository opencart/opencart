<?php
// En-tête
$_['heading_title'] = 'Informations';

// Texte
$_['text_contact']  = 'Contactez-Nous';
$_['text_sitemap']  = 'Carte du Site';
