<?php
// Text
$_['text_success']   = 'Success: Your reward points discount has been applied!';

// Error
$_['error_customer'] = 'Warning: Customer details required!';
$_['error_product']  = 'Warning: Products required!';
$_['error_points']   = 'Warning: You don\'t have %s reward points!';
$_['error_maximum']  = 'Warning: The maximum number of points that can be applied is %s!';
$_['error_status']   = 'Warning: Reward points are not enabled on this store!';
$_['error_confirm']  = 'Warning: Please check the reward form carefully for errors!';
