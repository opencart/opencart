<?php
// Text
$_['text_reward']  = 'Use Reward Points';

// Entry
$_['entry_reward'] = 'Use Reward Points';
