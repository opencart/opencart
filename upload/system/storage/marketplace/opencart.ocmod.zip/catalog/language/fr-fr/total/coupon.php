<?php
// Texte
$_['text_coupon'] = 'Coupon (%s)';
