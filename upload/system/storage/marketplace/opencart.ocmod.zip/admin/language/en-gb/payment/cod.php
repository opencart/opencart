<?php
// Heading
$_['heading_title']      = 'Cash On Delivery';

// Text
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Success: You have modified cash on delivery payment module!';
$_['text_edit']          = 'Edit Cash On Delivery';

// Entry
$_['entry_order_status'] = 'Order Status';
$_['entry_geo_zone']     = 'Geo Zone';
$_['entry_status']       = 'Status';
$_['entry_sort_order']   = 'Sort Order';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify payment cash on delivery!';