<?php
namespace Opencart\System\Library;
class MyClass {
	public function test() {
		echo 'I have been called!';
	}
}