<?php
// En-tête
$_['heading_title']    = 'Totaux';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié le total totaux!';
$_['text_edit']        = 'Modifier le total totaux';

// Entrée
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Ordre de Tri';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier le total totaux!';
