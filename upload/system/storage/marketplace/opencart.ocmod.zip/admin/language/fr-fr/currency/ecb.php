<?php
// En-tête
$_['heading_title']    = 'Convertisseur de Devises de la Banque Centrale Européenne';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié le Convertisseur de devises de la banque centrale européenne!';
$_['text_edit']        = 'Modifier le Convertisseur de devises de la Banque Centrale Européenne';
$_['text_support']     = 'Cette extension requiert la devise EUR.';

// Entrée
$_['entry_status']     = 'Statut';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier le Convertisseur de devises de la banque centrale européenne!';
