<?php
// Text
$_['text_title']       = 'Free Shipping';
$_['text_description'] = 'Free Shipping';