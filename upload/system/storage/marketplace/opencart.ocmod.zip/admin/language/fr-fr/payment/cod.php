<?php
// En-tête
$_['heading_title']      = 'Contres Remboursements';

// Texte
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Succès: Vous avez modifié les forfaits des contres remboursements!';
$_['text_edit']          = 'Modifier les forfaits des contres remboursements';

// Entrée
$_['entry_order_status'] = 'Statut de la Commande';
$_['entry_geo_zone']     = 'Zone Géographique';
$_['entry_status']       = 'Statut';
$_['entry_sort_order']   = 'Ordre de Tri';

// Erreur
$_['error_permission']   = 'Attention: Vous n\'avez pas la permission de modifier les forfaits des contres remboursements!';
