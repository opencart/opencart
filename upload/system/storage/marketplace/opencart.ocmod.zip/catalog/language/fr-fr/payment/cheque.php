<?php
// En-tête
$_['heading_title']    = 'Chèque / Mandat Poste';

// Texte
$_['text_instruction'] = 'Instructions de Chèque / Mandat Poste';
$_['text_payable']     = 'Exigibilité: ';
$_['text_address']     = 'Envoyé à: ';
$_['text_payment']     = 'Votre commande sera livrée lors de la réception de votre paiement.';
