<?php
// En-tête
$_['heading_title']    = 'Filtre';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié le module des filtres!';
$_['text_edit']        = 'Modifier le Module des Filtres';

// Entrée
$_['entry_status']     = 'Statut';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier le module des filtres!';
