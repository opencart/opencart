<?php
// En-tête
$_['heading_title'] = 'Nos Spéciaux';
