<?php
function my_function() {
	echo 'works';
}