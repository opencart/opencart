<?php
// Heading
$_['heading_title']    = 'Flat Rate';

// Text
$_['text_description'] = 'Flat Shipping Rate';
