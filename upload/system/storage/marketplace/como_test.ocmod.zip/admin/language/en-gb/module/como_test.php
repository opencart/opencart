<?php
// Heading
$_['heading_title']         = 'Como Test extension';

// Text
$_['text_extension']              = 'Extensions';
$_['text_success']                = 'Success: You have modified Como Test extension module!';
$_['text_edit']                   = 'Edit Como Test extension module';

// Entry
$_['entry_status']                = 'Status';

// Error
$_['error_permission']        = 'Warning: You do not have permission for Como Test extension!';
