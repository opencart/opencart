<?php
namespace Opencart\System\Library\Extension\OcThemeExample;
class MyClass {
	public function test() {
		echo 'I have been called!';
	}
}